package com.example.listacrud

data class Item(
    val id: Int,  // ID único do item
    val nome: String,  // Nome do item
    val descricao: String  // Descrição do item
)

