package com.example.listacrud

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var dbHelper: DBHelper  // Instância do DBHelper para manipulação do banco de dados
    private lateinit var recyclerView: RecyclerView  // RecyclerView para exibir a lista de itens
    private lateinit var itemAdapter: ItemAdapter  // Adaptador que conecta os dados ao RecyclerView
    private lateinit var addButton: Button  // Botão para adicionar novos itens
    private var items = mutableListOf<Item>()  // Lista mutable para armazenar os itens

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        dbHelper = DBHelper(this)  // Inicializa o DBHelper
        recyclerView = findViewById(R.id.recyclerView)  // Inicializa o RecyclerView
        addButton = findViewById(R.id.addButton)  // Inicializa o botão de adicionar

        recyclerView.layoutManager = LinearLayoutManager(this)  // Define o LayoutManager para o RecyclerView
        itemAdapter = ItemAdapter(items) { item ->  // Inicializa o adaptador, passando a lista de itens e a ação de clique
            openItemDetail(item)  // Chama a função para abrir os detalhes do item
        }
        recyclerView.adapter = itemAdapter  // Define o adaptador do RecyclerView

        addButton.setOnClickListener {
            openItemDetail(Item(0, "", ""))  // Ao clicar no botão, abre a tela de detalhes com um item em branco
        }

        loadItems()  // Carrega os itens ao iniciar a Activity
    }

    // Função para carregar todos os itens do banco de dados
    fun loadItems() {
        items.clear()  // Limpa a lista de itens existente
        items.addAll(dbHelper.getAllItems())  // Carrega todos os itens do banco de dados
        itemAdapter.notifyDataSetChanged()  // Notifica o adaptador para atualizar a RecyclerView
    }

    // Função para abrir a tela de detalhes do item
    fun openItemDetail(item: Item) {
        val intent = Intent(this, ItemDetailActivity::class.java)  // Cria um Intent para abrir a Activity de detalhes
        intent.putExtra("ITEM_ID", item.id)  // Passa o ID do item para a próxima Activity
        startActivityForResult(intent, 1)  // Inicia a Activity e aguarda o resultado
    }

    // Função para excluir um item da lista
    fun deleteItem(item: Item) {
        dbHelper.deleteItem(item.id)  // Deleta o item do banco de dados
        loadItems()  // Recarrega a lista de itens após a exclusão
        Toast.makeText(this, "Item excluído", Toast.LENGTH_SHORT).show()  // Exibe uma mensagem de confirmação
    }

    // Sobrescreve o método onActivityResult para recarregar os itens após a edição ou criação de um item
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK) {  // Verifica se a operação foi bem-sucedida
            loadItems()  // Recarrega os itens após adicionar ou editar
        }
    }
}

