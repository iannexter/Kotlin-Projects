package com.example.listacrud

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class ItemDetailActivity : AppCompatActivity() {

    private lateinit var dbHelper: DBHelper
    private lateinit var itemNameEditText: EditText
    private lateinit var itemDescriptionEditText: EditText
    private lateinit var saveButton: Button
    private var itemId: Int = 0 // ID do item, se for edição

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_item_detail)

        dbHelper = DBHelper(this)
        itemNameEditText = findViewById(R.id.itemNameEditText)
        itemDescriptionEditText = findViewById(R.id.itemDescriptionEditText)
        saveButton = findViewById(R.id.saveButton)

        // Verificar se é uma edição ou um novo item
        itemId = intent.getIntExtra("ITEM_ID", 0)
        if (itemId != 0) {
            // Carregar os dados do item existente para edição
            val item = dbHelper.getItemById(itemId)
            itemNameEditText.setText(item.nome)
            itemDescriptionEditText.setText(item.descricao)
        }

        saveButton.setOnClickListener {
            val name = itemNameEditText.text.toString()
            val description = itemDescriptionEditText.text.toString()

            if (itemId == 0) {
                // Adicionar novo item
                val newItem = Item(0, name, description)
                dbHelper.addItem(newItem)
            } else {
                // Atualizar item existente
                val updatedItem = Item(itemId, name, description)
                dbHelper.updateItem(updatedItem)
            }

            // Informar que a operação foi concluída com sucesso
            setResult(RESULT_OK)
            finish() // Fechar a activity depois de salvar
        }
    }
}
