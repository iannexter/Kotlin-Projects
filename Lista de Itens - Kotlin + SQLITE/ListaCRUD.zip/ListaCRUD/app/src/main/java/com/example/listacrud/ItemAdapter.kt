package com.example.listacrud

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ItemAdapter(private val items: List<Item>, private val onClick: (Item) -> Unit) :
    RecyclerView.Adapter<ItemAdapter.ItemViewHolder>() {

    // Classe ViewHolder que mantém as referências para os componentes de UI
    inner class ItemViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val itemName: TextView = view.findViewById(R.id.itemName)  // Referência para o nome do item
        val itemDescription: TextView = view.findViewById(R.id.itemDescription)  // Referência para a descrição
        val deleteButton: Button = view.findViewById(R.id.deleteButton)  // Referência para o botão de deletar
    }

    // Método chamado para criar a ViewHolder, inflando o layout do item
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_layout, parent, false)
        return ItemViewHolder(view)  // Retorna uma nova instância de ItemViewHolder
    }

    // Método chamado para associar os dados a cada item da lista
    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val item = items[position]  // Recupera o item da lista baseado na posição
        holder.itemName.text = item.nome  // Define o nome do item
        holder.itemDescription.text = item.descricao  // Define a descrição do item

        holder.itemView.setOnClickListener {  // Configura o clique no item
            onClick(item)  // Chama a função onClick fornecida no construtor
        }

        holder.deleteButton.setOnClickListener {  // Configura o clique no botão de deletar
            (holder.itemView.context as MainActivity).deleteItem(item)  // Deleta o item e recarrega a lista
        }
    }

    // Retorna a quantidade de itens na lista
    override fun getItemCount(): Int = items.size
}

