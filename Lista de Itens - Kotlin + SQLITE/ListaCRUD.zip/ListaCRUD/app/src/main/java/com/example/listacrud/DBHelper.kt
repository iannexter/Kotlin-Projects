package com.example.listacrud

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log

class DBHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {
    // A classe DBHelper é responsável pela criação e gerenciamento do banco de dados SQLite.
    // Ela herda de SQLiteOpenHelper para facilitar a criação e manipulação do banco de dados.

    companion object {
        // O companion object contém constantes que são usadas em todo o código.
        const val DATABASE_NAME = "items_db"  // Nome do banco de dados
        const val DATABASE_VERSION = 1         // Versão do banco de dados
        const val TABLE_NAME = "items"         // Nome da tabela no banco
        const val COLUMN_ID = "id"            // Nome da coluna de ID
        const val COLUMN_NAME = "name"        // Nome da coluna de nome
        const val COLUMN_DESCRIPTION = "description" // Nome da coluna de descrição
    }

    override fun onCreate(db: SQLiteDatabase?) {
        // Método chamado para criar o banco de dados quando ele é criado pela primeira vez.
        val CREATE_TABLE = "CREATE TABLE $TABLE_NAME (" +
                "$COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT," +  // A coluna ID será a chave primária e autoincrementada
                "$COLUMN_NAME TEXT," +  // A coluna de nome é do tipo texto
                "$COLUMN_DESCRIPTION TEXT)"  // A coluna de descrição é do tipo texto
        db?.execSQL(CREATE_TABLE)  // Executa o comando SQL para criar a tabela
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        // Método chamado quando a versão do banco de dados é atualizada.
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")  // Exclui a tabela existente, se houver
        onCreate(db)  // Chama o método onCreate para recriar a tabela com a nova estrutura
    }

    // Função para adicionar um novo item ao banco de dados
    fun addItem(item: Item): Long {
        val db = writableDatabase  // Obtém uma instância do banco de dados para escrita
        val values = ContentValues().apply {
            put(COLUMN_NAME, item.nome)  // Coloca o nome do item nos valores a serem inseridos
            put(COLUMN_DESCRIPTION, item.descricao)  // Coloca a descrição do item nos valores a serem inseridos
        }
        return db.insert(TABLE_NAME, null, values)  // Insere o item na tabela e retorna o ID do item inserido
    }

    // Função para recuperar todos os itens do banco de dados
    fun getAllItems(): List<Item> {
        val db = readableDatabase  // Obtém uma instância do banco de dados para leitura
        val cursor: Cursor = db.rawQuery("SELECT * FROM $TABLE_NAME", null)  // Executa a query para pegar todos os itens
        val items = mutableListOf<Item>()  // Lista que armazenará todos os itens recuperados

        if (cursor.moveToFirst()) {  // Verifica se há ao menos um item no cursor
            do {
                // Recupera os dados de cada item do cursor e os adiciona à lista
                val id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID))
                val nome = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME))
                val descricao = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DESCRIPTION))
                items.add(Item(id, nome, descricao))
            } while (cursor.moveToNext())  // Continua a iterar até o final dos resultados
        } else {
            Log.d("DBHelper", "Nenhum item encontrado.")  // Se o cursor estiver vazio, loga uma mensagem
        }

        cursor.close()  // Fecha o cursor para liberar recursos
        return items  // Retorna a lista de itens
    }

    // Função para recuperar um item específico pelo seu ID
    fun getItemById(id: Int): Item {
        val db = readableDatabase  // Obtém uma instância do banco de dados para leitura
        val cursor: Cursor = db.query(
            TABLE_NAME,  // Tabela
            arrayOf(COLUMN_ID, COLUMN_NAME, COLUMN_DESCRIPTION),  // Colunas a serem recuperadas
            "$COLUMN_ID = ?",  // Condição de filtro
            arrayOf(id.toString()),  // Valor do ID a ser buscado
            null, null, null  // Não há agrupamento, ordenação ou limitação
        )

        var item = Item(0, "", "")  // Valor padrão caso o item não seja encontrado
        if (cursor.moveToFirst()) {  // Se houver um resultado
            // Recupera os dados do cursor e cria um objeto Item
            val itemId = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID))
            val itemName = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME))
            val itemDescription = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DESCRIPTION))
            item = Item(itemId, itemName, itemDescription)
        } else {
            Log.d("DBHelper", "Item com ID $id não encontrado.")  // Se o item não for encontrado
        }
        cursor.close()  // Fecha o cursor para liberar recursos
        return item  // Retorna o item encontrado ou o item padrão
    }

    // Função para atualizar os dados de um item existente
    fun updateItem(item: Item): Int {
        val db = writableDatabase  // Obtém uma instância do banco de dados para escrita
        val values = ContentValues().apply {
            put(COLUMN_NAME, item.nome)  // Coloca o nome atualizado do item
            put(COLUMN_DESCRIPTION, item.descricao)  // Coloca a descrição atualizada do item
        }
        return db.update(TABLE_NAME, values, "$COLUMN_ID = ?", arrayOf(item.id.toString()))  // Atualiza o item no banco de dados
    }

    // Função para deletar um item do banco de dados
    fun deleteItem(id: Int): Int {
        val db = writableDatabase  // Obtém uma instância do banco de dados para escrita
        return db.delete(TABLE_NAME, "$COLUMN_ID = ?", arrayOf(id.toString()))  // Deleta o item baseado no ID
    }
}

